const CACHE = 'time-served-v1';
const ASSETS = [
  './Time Served Estimator.dc.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './_ds/nocturne-dd038d4c-7653-4bf7-a89d-dcb6d549c6a7/styles.css',
  './_ds/nocturne-dd038d4c-7653-4bf7-a89d-dcb6d549c6a7/_ds_bundle.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then((cached) => {
      const fetchPromise = fetch(e.request).then((res) => {
        if (res && res.status === 200) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
